#ifndef _H_DATA2INT
#define _H_DATA2INT	1


void read_data(FILE *file, int **tables, int noofrows, int noofattrs);


#endif
